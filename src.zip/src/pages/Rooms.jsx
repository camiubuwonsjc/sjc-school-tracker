import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { 
  Wind, 
  Lightbulb, 
  Lock, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  ShieldCheck,
  Check
} from 'lucide-react';

export default function Rooms({ rooms, user }) {
  const [activeFloor, setActiveFloor] = useState(1);
  const [updatingRoomId, setUpdatingRoomId] = useState(null);

  // Filter rooms for the currently selected floor
  const floorRooms = rooms.filter((r) => r.floor === activeFloor);

  // Status configuration map for styling and labels
  const statusConfig = {
    pending: {
      label: 'Pending',
      bg: 'bg-amber-50 text-amber-700 border-amber-200',
      icon: Clock,
    },
    cleaned: {
      label: 'Cleaned',
      bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      icon: CheckCircle2,
    },
    needs_reclean: {
      label: 'Needs Reclean',
      bg: 'bg-red-50 text-red-700 border-red-200',
      icon: AlertCircle,
    },
    verified: {
      label: 'Verified',
      bg: 'bg-blue-50 text-blue-700 border-blue-200',
      icon: ShieldCheck,
    },
  };

  // Update room fields in Supabase
  const handleUpdateRoom = async (roomId, updates) => {
    setUpdatingRoomId(roomId);
    const { error } = await supabase
      .from('rooms')
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq('id', roomId);

    if (error) {
      console.error('Failed to update room status:', error);
    }
    setUpdatingRoomId(null);
  };

  return (
    <div className="space-y-4 pb-8">
      {/* Page Title Header */}
      <div className="flex items-center justify-between bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm">
        <div>
          <h2 className="text-base font-bold text-slate-800">Room Inspections</h2>
          <p className="text-xs text-slate-500">Floor {activeFloor} • 5 Rooms</p>
        </div>
        <div className="text-xs font-semibold px-3 py-1 bg-emerald-50 text-[#176e57] rounded-full border border-emerald-100">
          35 Total Rooms
        </div>
      </div>

      {/* Horizontal Floor Selection Tabs (Floors 1 – 7) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {[1, 2, 3, 4, 5, 6, 7].map((floorNum) => {
          const isActive = activeFloor === floorNum;
          return (
            <button
              key={floorNum}
              onClick={() => setActiveFloor(floorNum)}
              className={`flex-1 min-w-[50px] py-2.5 rounded-2xl font-bold text-xs transition-all ${
                isActive
                  ? 'bg-[#176e57] text-white shadow-md shadow-emerald-900/10 scale-105'
                  : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-50'
              }`}
            >
              F{floorNum}
            </button>
          );
        })}
      </div>

      {/* Room Cards List */}
      <div className="space-y-3">
        {floorRooms.length === 0 ? (
          <div className="bg-white p-8 rounded-3xl border border-slate-200/80 text-center space-y-2">
            <p className="text-sm font-semibold text-slate-600">No rooms loaded for Floor {activeFloor}</p>
            <p className="text-xs text-slate-400">Ensure room data is initialized in your Supabase database.</p>
          </div>
        ) : (
          floorRooms.map((room) => {
            const currentStatus = statusConfig[room.status] || statusConfig.pending;
            const StatusIcon = currentStatus.icon;
            const isUpdating = updatingRoomId === room.id;

            return (
              <div
                key={room.id}
                className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm space-y-3 relative overflow-hidden"
              >
                {/* Card Top Row: Room Number & Current Status */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-2xl bg-slate-100 text-slate-800 flex items-center justify-center font-black text-sm">
                      {room.room_number || room.id}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800 text-sm">
                        Room {room.room_number || room.id}
                      </h3>
                      <p className="text-[10px] text-slate-400">Floor {room.floor}</p>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${currentStatus.bg}`}>
                    <StatusIcon className="w-3.5 h-3.5" />
                    <span>{currentStatus.label}</span>
                  </div>
                </div>

                {/* Status Selector Pills */}
                <div className="grid grid-cols-4 gap-1 pt-1 bg-slate-50 p-1 rounded-2xl border border-slate-100">
                  {['pending', 'cleaned', 'needs_reclean', 'verified'].map((statusKey) => {
                    const isSelected = room.status === statusKey;
                    return (
                      <button
                        key={statusKey}
                        disabled={isUpdating}
                        onClick={() => handleUpdateRoom(room.id, { status: statusKey })}
                        className={`py-1.5 rounded-xl text-[10px] font-bold capitalize transition-all ${
                          isSelected
                            ? statusKey === 'verified'
                              ? 'bg-blue-600 text-white shadow-sm'
                              : statusKey === 'needs_reclean'
                              ? 'bg-red-600 text-white shadow-sm'
                              : statusKey === 'cleaned'
                              ? 'bg-[#176e57] text-white shadow-sm'
                              : 'bg-amber-500 text-white shadow-sm'
                            : 'text-slate-500 hover:bg-slate-200/60'
                        }`}
                      >
                        {statusKey.replace('_', ' ')}
                      </button>
                    );
                  })}
                </div>

                {/* Safety Check Toggles (AC, Lighting, Door Lock) */}
                <div className="pt-2 border-t border-slate-100 grid grid-cols-3 gap-2">
                  {/* AC Switch Toggle */}
                  <button
                    disabled={isUpdating}
                    onClick={() =>
                      handleUpdateRoom(room.id, { ac_switch: !room.ac_switch })
                    }
                    className={`flex items-center justify-between p-2 rounded-2xl border transition-all text-left ${
                      room.ac_switch
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : 'bg-slate-50 border-slate-200/80 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <Wind className="w-3.5 h-3.5" />
                      <span className="text-[10px] font-bold">AC Off</span>
                    </div>
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center text-white ${room.ac_switch ? 'bg-[#176e57]' : 'bg-slate-300'}`}>
                      {room.ac_switch && <Check className="w-2.5 h-2.5" />}
                    </div>
                  </button>

                  {/* Lighting Switch Toggle */}
                  <button
                    disabled={isUpdating}
                    onClick={() =>
                      handleUpdateRoom(room.id, { lighting_switch: !room.lighting_switch })
                    }
                    className={`flex items-center justify-between p-2 rounded-2xl border transition-all text-left ${
                      room.lighting_switch
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : 'bg-slate-50 border-slate-200/80 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <Lightbulb className="w-3.5 h-3.5" />
                      <span className="text-[10px] font-bold">Lights Off</span>
                    </div>
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center text-white ${room.lighting_switch ? 'bg-[#176e57]' : 'bg-slate-300'}`}>
                      {room.lighting_switch && <Check className="w-2.5 h-2.5" />}
                    </div>
                  </button>

                  {/* Door Lock Toggle */}
                  <button
                    disabled={isUpdating}
                    onClick={() =>
                      handleUpdateRoom(room.id, { door_locked: !room.door_locked })
                    }
                    className={`flex items-center justify-between p-2 rounded-2xl border transition-all text-left ${
                      room.door_locked
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : 'bg-slate-50 border-slate-200/80 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5" />
                      <span className="text-[10px] font-bold">Locked</span>
                    </div>
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center text-white ${room.door_locked ? 'bg-[#176e57]' : 'bg-slate-300'}`}>
                      {room.door_locked && <Check className="w-2.5 h-2.5" />}
                    </div>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}