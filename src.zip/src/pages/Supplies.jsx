import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { 
  Package, 
  Search, 
  Plus, 
  Minus, 
  Trash2, 
  AlertTriangle, 
  CheckCircle2,
  Box
} from 'lucide-react';

export default function Supplies({ supplies, user }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [updatingId, setUpdatingId] = useState(null);

  const categories = ['All', 'Chemicals', 'Equipment', 'Disposables', 'Hygiene', 'PPE'];

  // Calculate low stock items count
  const lowStockCount = supplies.filter((s) => s.count <= s.threshold).length;

  // Filter supplies by category and search term
  const filteredSupplies = supplies.filter((item) => {
    const matchesCategory = activeCategory === 'All' || item.category === activeCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Handle quantity increment/decrement directly in Supabase
  const handleUpdateQuantity = async (supplyId, currentCount, delta) => {
    const newCount = Math.max(0, currentCount + delta);
    setUpdatingId(supplyId);

    const { error } = await supabase
      .from('supplies')
      .update({
        count: newCount,
        updated_at: new Date().toISOString(),
      })
      .eq('id', supplyId);

    if (error) {
      console.error('Failed to update supply count:', error);
    }
    setUpdatingId(null);
  };

  // Delete Supply Item (Admin Supervisor Privilege)
  const handleDeleteSupply = async (supplyId) => {
    if (!window.confirm('Are you sure you want to permanently delete this supply item?')) return;

    const { error } = await supabase.from('supplies').delete().eq('id', supplyId);
    if (error) {
      console.error('Failed to delete supply item:', error);
    }
  };

  return (
    <div className="space-y-4 pb-8">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm">
        <div>
          <h2 className="text-base font-bold text-slate-800">Central Custodial Supplies</h2>
          <p className="text-xs text-slate-500">{supplies.length} Items Registered</p>
        </div>

        {lowStockCount > 0 ? (
          <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-full text-xs font-bold animate-pulse">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{lowStockCount} Low Stock</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-[#176e57] border border-emerald-200 rounded-full text-xs font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Fully Stocked</span>
          </div>
        )}
      </div>

      {/* Search Bar Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search supplies or categories..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200/80 rounded-2xl text-xs focus:outline-none focus:ring-2 focus:ring-[#176e57] shadow-sm"
        />
      </div>

      {/* Category Filter Horizontal Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((category) => {
          const isActive = activeCategory === category;
          return (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-[#176e57] text-white shadow-md shadow-emerald-900/10'
                  : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-50'
              }`}
            >
              {category}
            </button>
          );
        })}
      </div>

      {/* Supply Cards Grid */}
      <div className="space-y-3">
        {filteredSupplies.length === 0 ? (
          <div className="bg-white p-8 rounded-3xl border border-slate-200/80 text-center space-y-2">
            <Box className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm font-semibold text-slate-600">No supplies found</p>
            <p className="text-xs text-slate-400">
              Try adjusting your search query or select another category.
            </p>
          </div>
        ) : (
          filteredSupplies.map((item) => {
            const isLowStock = item.count <= item.threshold;
            const isUpdating = updatingId === item.id;

            return (
              <div
                key={item.id}
                className={`bg-white p-4 rounded-3xl border shadow-sm transition-all space-y-3 ${
                  isLowStock ? 'border-amber-300 bg-amber-50/20' : 'border-slate-200/80'
                }`}
              >
                {/* Top Info Row */}
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-0.5 bg-slate-100 rounded-md">
                        {item.category}
                      </span>
                      {isLowStock && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">
                          <AlertTriangle className="w-3 h-3" /> Low Stock
                        </span>
                      )}
                    </div>
                    <h3 className="font-bold text-slate-800 text-sm">{item.name}</h3>
                  </div>

                  {/* Admin Delete Action */}
                  {user.role === 'admin' && (
                    <button
                      onClick={() => handleDeleteSupply(item.id)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                      title="Remove supply item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Bottom Row: Stock Counters & Unit Info */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                  <div className="text-xs">
                    <span className="text-slate-400">Threshold: </span>
                    <span className="font-semibold text-slate-600">
                      {item.threshold} {item.unit}
                    </span>
                  </div>

                  {/* Counter Buttons */}
                  <div className="flex items-center gap-2 bg-slate-50 p-1 rounded-2xl border border-slate-200">
                    <button
                      disabled={isUpdating || item.count === 0}
                      onClick={() => handleUpdateQuantity(item.id, item.count, -1)}
                      className="w-8 h-8 rounded-xl bg-white text-slate-700 hover:bg-slate-200/80 flex items-center justify-center font-bold shadow-xs active:scale-95 transition-all disabled:opacity-40"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>

                    <div className="px-2 text-center min-w-[40px]">
                      <span className={`font-black text-sm ${isLowStock ? 'text-amber-600' : 'text-slate-800'}`}>
                        {item.count}
                      </span>
                      <span className="text-[9px] text-slate-400 block -mt-1">{item.unit}</span>
                    </div>

                    <button
                      disabled={isUpdating}
                      onClick={() => handleUpdateQuantity(item.id, item.count, 1)}
                      className="w-8 h-8 rounded-xl bg-[#176e57] text-white hover:bg-[#125744] flex items-center justify-center font-bold shadow-xs active:scale-95 transition-all disabled:opacity-40"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}