import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { 
  Megaphone, 
  Users, 
  PackagePlus, 
  RotateCcw, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck,
  Send,
  Plus
} from 'lucide-react';

export default function Admin({ rooms, supplies, user }) {
  // 1. Notice Broadcast State
  const [noticeMessage, setNoticeMessage] = useState('');
  const [isNoticeActive, setIsNoticeActive] = useState(false);
  const [isSavingNotice, setIsSavingNotice] = useState(false);

  // 2. Staff Floor Assignments State
  const [assignments, setAssignments] = useState({});
  const [isSavingAssignment, setIsSavingAssignment] = useState(false);

  // 3. New Stock Registration State
  const [stockName, setStockName] = useState('');
  const [stockCategory, setStockCategory] = useState('Chemicals');
  const [stockCount, setStockCount] = useState(10);
  const [stockThreshold, setStockThreshold] = useState(5);
  const [stockUnit, setStockUnit] = useState('pcs');
  const [isAddingStock, setIsAddingStock] = useState(false);
  const [stockSuccess, setStockSuccess] = useState(false);

  // 4. Shift Rollover Modal State
  const [showRolloverModal, setShowRolloverModal] = useState(false);
  const [isRollingOver, setIsRollingOver] = useState(false);

  // Fetch initial Broadcast & Assignments from Supabase
  useEffect(() => {
    const fetchAdminData = async () => {
      // Fetch Broadcast
      const { data: bData } = await supabase.from('broadcast').select('*').eq('id', 1).maybeSingle();
      if (bData) {
        setNoticeMessage(bData.message || '');
        setIsNoticeActive(bData.active || false);
      }

      // Fetch Floor Assignments
      const { data: aData } = await supabase.from('assignments').select('*');
      if (aData) {
        const assignmentMap = {};
        aData.forEach((item) => {
          assignmentMap[item.floor] = item.staff_id;
        });
        setAssignments(assignmentMap);
      }
    };

    fetchAdminData();
  }, []);

  // Save/Update Notice Broadcast
  const handleSaveNotice = async (e) => {
    e.preventDefault();
    setIsSavingNotice(true);

    const { error } = await supabase.from('broadcast').upsert({
      id: 1,
      message: noticeMessage.trim(),
      active: true,
      updated_at: new Date().toISOString(),
    });

    if (!error) {
      setIsNoticeActive(true);
    }
    setIsSavingNotice(false);
  };

  // Clear Global Broadcast Notice
  const handleClearNotice = async () => {
    setIsSavingNotice(true);
    const { error } = await supabase.from('broadcast').upsert({
      id: 1,
      message: '',
      active: false,
      updated_at: new Date().toISOString(),
    });

    if (!error) {
      setNoticeMessage('');
      setIsNoticeActive(false);
    }
    setIsSavingNotice(false);
  };

  // Assign Staff ID to Floor
  const handleAssignStaff = async (floorNum, staffId) => {
    setIsSavingAssignment(true);
    const staffNames = {
      '001': 'Custodial Staff #001',
      '002': 'Custodial Staff #002',
      '003': 'Custodial Staff #003',
      '004': 'Custodial Staff #004',
      '005': 'Custodial Staff #005',
    };

    const { error } = await supabase.from('assignments').upsert({
      floor: floorNum,
      staff_id: staffId,
      staff_name: staffNames[staffId] || `Staff #${staffId}`,
      updated_at: new Date().toISOString(),
    });

    if (!error) {
      setAssignments((prev) => ({ ...prev, [floorNum]: staffId }));
    }
    setIsSavingAssignment(false);
  };

  // Register New Stock Item
  const handleAddStock = async (e) => {
    e.preventDefault();
    if (!stockName.trim()) return;

    setIsAddingStock(true);
    const { error } = await supabase.from('supplies').insert({
      name: stockName.trim(),
      category: stockCategory,
      count: Number(stockCount),
      threshold: Number(stockThreshold),
      unit: stockUnit.trim() || 'pcs',
      updated_at: new Date().toISOString(),
    });

    if (!error) {
      setStockName('');
      setStockCount(10);
      setStockThreshold(5);
      setStockSuccess(true);
      setTimeout(() => setStockSuccess(false), 3000);
    }
    setIsAddingStock(false);
  };

  // Execute Shift Rollover Reset across all 35 rooms
  const handleExecuteRollover = async () => {
    setIsRollingOver(true);
    const { error } = await supabase
      .from('rooms')
      .update({
        status: 'pending',
        ac_switch: false,
        lighting_switch: false,
        door_locked: false,
        updated_at: new Date().toISOString(),
      })
      .gte('floor', 1); // Select all floors 1 through 7

    if (!error) {
      setShowRolloverModal(false);
    } else {
      console.error('Failed to execute shift rollover:', error);
    }
    setIsRollingOver(false);
  };

  return (
    <div className="space-y-5 pb-8">
      {/* Page Header */}
      <div className="bg-amber-600 text-white p-5 rounded-3xl shadow-lg space-y-1 relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none" />
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-6 h-6 text-amber-200" />
          <h2 className="text-lg font-black tracking-tight">Supervisor Workspace</h2>
        </div>
        <p className="text-xs text-amber-100/90 font-medium">
          Dimasalang Hall Administrative & Shift Controls
        </p>
      </div>

      {/* 1. Broadcast Notice Management */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-amber-600">
            <Megaphone className="w-5 h-5" />
            <h3 className="font-bold text-slate-800 text-sm">School-Wide Broadcast Notice</h3>
          </div>
          {isNoticeActive && (
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full animate-pulse">
              Active Pin
            </span>
          )}
        </div>

        <form onSubmit={handleSaveNotice} className="space-y-3">
          <textarea
            rows={2}
            required
            placeholder="Type announcement pinned under app header..."
            value={noticeMessage}
            onChange={(e) => setNoticeMessage(e.target.value)}
            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-600"
          />

          <div className="flex gap-2">
            {isNoticeActive && (
              <button
                type="button"
                onClick={handleClearNotice}
                disabled={isSavingNotice}
                className="px-4 py-2 bg-red-50 text-red-600 rounded-xl font-bold text-xs hover:bg-red-100 transition-colors"
              >
                Clear Notice
              </button>
            )}
            <button
              type="submit"
              disabled={isSavingNotice}
              className="flex-1 py-2.5 bg-amber-600 text-white font-bold rounded-xl text-xs hover:bg-amber-700 transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isNoticeActive ? 'Update Broadcast' : 'Publish Broadcast'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* 2. Staff Floor Assignments */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
        <div className="flex items-center gap-2 text-amber-600">
          <Users className="w-5 h-5" />
          <h3 className="font-bold text-slate-800 text-sm">Staff Floor Roster Assignments</h3>
        </div>

        <div className="space-y-2 pt-1">
          {[1, 2, 3, 4, 5, 6, 7].map((floorNum) => (
            <div
              key={floorNum}
              className="flex items-center justify-between p-2.5 bg-slate-50 rounded-2xl border border-slate-200/60"
            >
              <span className="text-xs font-bold text-slate-700">Floor {floorNum}</span>
              <select
                value={assignments[floorNum] || '001'}
                onChange={(e) => handleAssignStaff(floorNum, e.target.value)}
                disabled={isSavingAssignment}
                className="bg-white border border-slate-200 rounded-xl px-2.5 py-1 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-600"
              >
                <option value="001">Staff #001</option>
                <option value="002">Staff #002</option>
                <option value="003">Staff #003</option>
                <option value="004">Staff #004</option>
                <option value="005">Staff #005</option>
              </select>
            </div>
          ))}
        </div>
      </div>

      {/* 3. New Stock Registration Form */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
        <div className="flex items-center gap-2 text-amber-600">
          <PackagePlus className="w-5 h-5" />
          <h3 className="font-bold text-slate-800 text-sm">Add New Supply Item</h3>
        </div>

        <form onSubmit={handleAddStock} className="space-y-3">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Item Name</label>
            <input
              type="text"
              required
              placeholder="e.g., Bleach Disinfectant 1L"
              value={stockName}
              onChange={(e) => setStockName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-600"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Category</label>
              <select
                value={stockCategory}
                onChange={(e) => setStockCategory(e.target.value)}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-600"
              >
                <option value="Chemicals">Chemicals</option>
                <option value="Equipment">Equipment</option>
                <option value="Disposables">Disposables</option>
                <option value="Hygiene">Hygiene</option>
                <option value="PPE">PPE</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Unit</label>
              <input
                type="text"
                required
                placeholder="pcs, bottles, rolls"
                value={stockUnit}
                onChange={(e) => setStockUnit(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Initial Stock</label>
              <input
                type="number"
                min="0"
                required
                value={stockCount}
                onChange={(e) => setStockCount(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-600"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Alert Threshold</label>
              <input
                type="number"
                min="1"
                required
                value={stockThreshold}
                onChange={(e) => setStockThreshold(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-600"
              />
            </div>
          </div>

          {stockSuccess && (
            <div className="p-2.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Supply item registered successfully!</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isAddingStock}
            className="w-full py-2.5 bg-amber-600 text-white font-bold rounded-xl text-xs hover:bg-amber-700 transition-colors flex items-center justify-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" /> Register Supply Item
          </button>
        </form>
      </div>

      {/* 4. Shift Rollover Reset Card */}
      <div className="bg-red-50/60 border border-red-200 p-4 rounded-3xl space-y-3">
        <div className="flex items-center gap-2 text-red-700">
          <RotateCcw className="w-5 h-5" />
          <h3 className="font-bold text-sm">Shift Rollover Reset</h3>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          Resets all 35 classroom statuses across Floors 1–7 back to "Pending" and clears safety switches (AC, lights, locks) for the next shift.
        </p>
        <button
          onClick={() => setShowRolloverModal(true)}
          className="w-full py-3 bg-red-600 text-white font-bold rounded-2xl text-xs hover:bg-red-700 transition-colors shadow-sm"
        >
          Initiate Shift Rollover
        </button>
      </div>

      {/* Rollover Confirmation Modal */}
      {showRolloverModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xs w-full p-5 shadow-2xl text-center space-y-3">
            <div className="w-12 h-12 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 text-base">Confirm Shift Rollover?</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              This action will set all 35 rooms to "Pending" and turn off all safety flags. This cannot be undone.
            </p>

            <div className="flex gap-2 pt-1">
              <button
                onClick={() => setShowRolloverModal(false)}
                className="flex-1 py-2.5 bg-slate-100 text-slate-600 rounded-xl font-semibold text-xs hover:bg-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleExecuteRollover}
                disabled={isRollingOver}
                className="flex-1 py-2.5 bg-red-600 text-white rounded-xl font-bold text-xs hover:bg-red-700 shadow-sm"
              >
                {isRollingOver ? 'Resetting...' : 'Confirm Reset'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
