import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import StaffPresenceModal from '../components/StaffPresenceModal';
import { 
  Building2, 
  Package, 
  Users, 
  Send, 
  Trash2, 
  AlertTriangle, 
  Sparkles, 
  ChevronRight,
  ClipboardCheck
} from 'lucide-react';

export default function Dashboard({ rooms, supplies, logs, onlineStaff, user }) {
  const navigate = useNavigate();
  const [isPresenceOpen, setIsPresenceOpen] = useState(false);
  const [newLogText, setNewLogText] = useState('');
  const [isSubmittingLog, setIsSubmittingLog] = useState(false);

  // Calculate sanitation progress (out of 35 total rooms)
  const totalRooms = 35;
  const cleanedRoomsCount = rooms.filter(
    (r) => r.status === 'cleaned' || r.status === 'verified'
  ).length;
  const progressPercent = Math.round((cleanedRoomsCount / totalRooms) * 100) || 0;

  // Calculate low stock alert count
  const lowStockCount = supplies.filter((s) => s.count <= s.threshold).length;

  // Submit Shift Handover Note (Rule: Do NOT call local state setter setLogs directly, let WebSocket handle sync)
  const handleAddLog = async (e) => {
    e.preventDefault();
    if (!newLogText.trim()) return;

    setIsSubmittingLog(true);
    const { error } = await supabase.from('logs').insert({
      text: newLogText.trim(),
      staff_id: user.id,
      staff_name: user.name,
      time: new Date().toISOString(),
    });

    if (!error) {
      setNewLogText('');
    } else {
      console.error('Failed to dispatch log entry:', error);
    }
    setIsSubmittingLog(false);
  };

  // Delete Log Note (Admin Privilege)
  const handleDeleteLog = async (logId) => {
    const { error } = await supabase.from('logs').delete().eq('id', logId);
    if (error) {
      console.error('Failed to delete log entry:', error);
    }
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Sanitation Progress Banner */}
      <div className="bg-gradient-to-br from-[#176e57] to-[#125744] rounded-3xl p-5 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-6 -mt-6 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none" />

        <div className="flex justify-between items-start mb-3">
          <div>
            <span className="text-[11px] uppercase tracking-wider font-semibold text-emerald-200">
              Daily Sanitation Overall
            </span>
            <h2 className="text-xl font-black mt-0.5">
              {cleanedRoomsCount} of {totalRooms} Rooms Ready
            </h2>
          </div>
          <span className="text-2xl font-black text-emerald-200 bg-white/10 px-3 py-1 rounded-2xl border border-white/10">
            {progressPercent}%
          </span>
        </div>

        {/* Progress Bar Container */}
        <div className="w-full bg-black/20 h-3 rounded-full overflow-hidden p-0.5 border border-white/10">
          <div
            className="bg-emerald-300 h-full rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-2 gap-3">
        {/* Rooms Card */}
        <div
          onClick={() => navigate('/rooms')}
          className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm hover:shadow-md cursor-pointer transition-all active:scale-95 space-y-3"
        >
          <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-[#176e57] flex items-center justify-center">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-800 text-sm">Room Matrix</h3>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">Floors 1 – 7 Status</p>
          </div>
        </div>

        {/* Supplies Card */}
        <div
          onClick={() => navigate('/supplies')}
          className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm hover:shadow-md cursor-pointer transition-all active:scale-95 space-y-3 relative"
        >
          <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-800 text-sm">Stockroom</h3>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>
            {lowStockCount > 0 ? (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full mt-1">
                <AlertTriangle className="w-3 h-3" /> {lowStockCount} Low Item{lowStockCount > 1 ? 's' : ''}
              </span>
            ) : (
              <p className="text-[11px] text-slate-500 mt-0.5">Inventory Stocked</p>
            )}
          </div>
        </div>
      </div>

      {/* Floor Assignment & Presence Header */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ClipboardCheck className="w-5 h-5 text-[#176e57]" />
            <h3 className="font-bold text-slate-800 text-sm">Floor Roster & Presence</h3>
          </div>
          <button
            onClick={() => setIsPresenceOpen(true)}
            className="flex items-center gap-1.5 bg-emerald-50 text-[#176e57] hover:bg-emerald-100 px-3 py-1.5 rounded-2xl text-xs font-bold transition-colors"
          >
            <Users className="w-3.5 h-3.5" />
            <span>Online Staff ({onlineStaff.length})</span>
          </button>
        </div>

        {/* Floor Cards Grid 1-7 */}
        <div className="grid grid-cols-7 gap-1.5 pt-1">
          {[1, 2, 3, 4, 5, 6, 7].map((floorNum) => {
            const floorRooms = rooms.filter((r) => r.floor === floorNum);
            const floorCleaned = floorRooms.filter(
              (r) => r.status === 'cleaned' || r.status === 'verified'
            ).length;
            const isFullyClean = floorRooms.length > 0 && floorCleaned === floorRooms.length;

            return (
              <div
                key={floorNum}
                onClick={() => navigate('/rooms')}
                className={`p-2 rounded-2xl text-center cursor-pointer border transition-all ${
                  isFullyClean
                    ? 'bg-emerald-500 text-white border-emerald-600'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="text-[10px] font-bold opacity-80">F{floorNum}</div>
                <div className="text-xs font-black">{floorCleaned}/5</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Shift Handover Feed Section */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
        <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#176e57]" /> Shift Handover Feed
        </h3>

        {/* Note Submission Input */}
        <form onSubmit={handleAddLog} className="flex gap-2">
          <input
            type="text"
            required
            placeholder="Log incident or shift note..."
            value={newLogText}
            onChange={(e) => setNewLogText(e.target.value)}
            className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs focus:outline-none focus:ring-2 focus:ring-[#176e57]"
          />
          <button
            type="submit"
            disabled={isSubmittingLog}
            className="px-4 bg-[#176e57] text-white rounded-2xl hover:bg-[#125744] transition-colors flex items-center justify-center"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        {/* Logs List */}
        <div className="space-y-2 pt-1 max-h-60 overflow-y-auto">
          {logs.length === 0 ? (
            <p className="text-center text-xs text-slate-400 py-4">No shift logs recorded today.</p>
          ) : (
            logs.map((log) => (
              <div
                key={log.id}
                className="p-3 bg-slate-50 rounded-2xl border border-slate-200/60 flex items-start justify-between gap-2"
              >
                <div className="space-y-1">
                  <p className="text-xs text-slate-800 font-medium leading-relaxed">{log.text}</p>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400">
                    <span className="font-bold text-slate-600">{log.staff_name}</span>
                    <span>•</span>
                    <span>{new Date(log.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>

                {/* Supervisor Admin Deletion Button */}
                {user.role === 'admin' && (
                  <button
                    onClick={() => handleDeleteLog(log.id)}
                    className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                    title="Delete log entry"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Staff Presence Modal Trigger */}
      <StaffPresenceModal
        isOpen={isPresenceOpen}
        onClose={() => setIsPresenceOpen(false)}
        onlineStaff={onlineStaff}
      />
    </div>
  );
}