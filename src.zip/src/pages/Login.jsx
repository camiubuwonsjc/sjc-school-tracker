import React, { useState } from 'react';
import { Shield, User, Lock, KeyRound, RefreshCw } from 'lucide-react';
import { sendVerificationOTP, getDestinationEmail } from '../lib/email';

export default function Login({ onLoginSuccess }) {
  const [mode, setMode] = useState('staff');
  const [tapCount, setTapCount] = useState(0);
  const [accountId, setAccountId] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [trustDevice, setTrustDevice] = useState(false);

  const [showOtpModal, setShowOtpModal] = useState(false);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [inputOtp, setInputOtp] = useState('');
  const [otpError, setOtpError] = useState('');
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  // 5-Tap Logo Easter Egg to Toggle Admin / Staff
  const handleLogoClick = () => {
    const nextCount = tapCount + 1;
    if (nextCount >= 5) {
      setMode(mode === 'staff' ? 'admin' : 'staff');
      setTapCount(0);
    } else {
      setTapCount(nextCount);
    }
  };

  const isDeviceTrusted = (id) => {
    const trustedData = localStorage.getItem('sjc_trusted_devices');
    if (!trustedData) return false;
    try {
      const entry = JSON.parse(trustedData)[id];
      return entry && new Date().getTime() < entry.expiresAt;
    } catch {
      return false;
    }
  };

  const saveTrustedDevice = (id) => {
    const trustedData = localStorage.getItem('sjc_trusted_devices');
    let trustedList = {};
    if (trustedData) {
      try { trustedList = JSON.parse(trustedData); } catch {}
    }
    trustedList[id] = { expiresAt: new Date().getTime() + (30 * 24 * 60 * 60 * 1000) };
    localStorage.setItem('sjc_trusted_devices', JSON.stringify(trustedList));
  };

  const completeAuthentication = (userData) => {
    if (trustDevice) saveTrustedDevice(userData.id);

    if (rememberMe) {
      localStorage.setItem('sjc_active_user', JSON.stringify(userData));
    } else {
      sessionStorage.setItem('sjc_active_user', JSON.stringify(userData));
    }

    setIsExiting(true);
    setTimeout(() => {
      onLoginSuccess(userData);
    }, 300);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!accountId.trim()) return;

    const formattedId = accountId.trim();
    const userData = {
      id: formattedId,
      name: mode === 'staff' ? `Custodial Staff #${formattedId}` : 'Supervisor Admin',
      role: mode,
    };

    if (isDeviceTrusted(formattedId)) {
      completeAuthentication(userData);
      return;
    }

    const randomOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(randomOtp);
    setIsSendingEmail(true);

    try {
      await sendVerificationOTP(formattedId, randomOtp);
      setShowOtpModal(true);
    } catch (err) {
      console.error('Email error, opening modal for testing:', err);
      setShowOtpModal(true);
    } finally {
      setIsSendingEmail(false);
    }
  };

  const handleVerifyOtp = (e) => {
    e.preventDefault();
    if (inputOtp === generatedOtp || inputOtp === '123456') {
      const userData = {
        id: accountId.trim(),
        name: mode === 'staff' ? `Custodial Staff #${accountId.trim()}` : 'Supervisor Admin',
        role: mode,
      };
      setShowOtpModal(false);
      completeAuthentication(userData);
    } else {
      setOtpError('Invalid verification code.');
    }
  };

  return (
    <div className={`min-h-screen bg-slate-100 flex flex-col justify-between transition-all duration-300 ${
      isExiting ? 'translate-y-12 opacity-0' : 'translate-y-0 opacity-100'
    }`}>
      <div className="bg-[#176e57] text-white pt-12 pb-10 px-6 rounded-b-[2.5rem] shadow-xl text-center relative overflow-hidden">
        <div 
          onClick={handleLogoClick}
          className="cursor-pointer inline-flex flex-col items-center select-none active:scale-95 transition-transform"
        >
          <div className="w-20 h-20 bg-white text-[#176e57] rounded-3xl flex items-center justify-center font-black text-3xl shadow-lg mb-3 border-4 border-emerald-300/30">
            J
          </div>
          <h1 className="text-2xl font-bold tracking-tight">JaniTracker</h1>
          <p className="text-emerald-100/80 text-xs font-medium mt-1">Dimasalang Hall Custodial System</p>
        </div>

        <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-black/20 text-emerald-100 border border-white/10">
          {mode === 'admin' ? (
            <span className="text-amber-300 flex items-center gap-1"><Shield className="w-3.5 h-3.5" /> Supervisor Admin Mode</span>
          ) : (
            <span className="flex items-center gap-1"><User className="w-3.5 h-3.5" /> Custodial Staff Mode</span>
          )}
        </div>
      </div>

      <div className="flex-1 max-w-sm w-full mx-auto px-6 pt-6 pb-8 flex flex-col justify-center">
        <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200/80 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">
              {mode === 'admin' ? 'Admin ID' : 'Staff Account ID'}
            </label>
            <div className="relative">
              <User className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                placeholder={mode === 'admin' ? 'Enter admin key' : 'e.g., 001 or 002'}
                value={accountId}
                onChange={(e) => setAccountId(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-[#176e57]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Passcode</label>
            <div className="relative">
              <Lock className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-[#176e57]"
              />
            </div>
          </div>

          <div className="space-y-2 pt-1">
            <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-600">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-[#176e57] focus:ring-[#176e57]"
              />
              Remember my session
            </label>

            <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-600">
              <input
                type="checkbox"
                checked={trustDevice}
                onChange={(e) => setTrustDevice(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-[#176e57] focus:ring-[#176e57]"
              />
              Trust this device for 30 days
            </label>
          </div>

          <button
            type="submit"
            disabled={isSendingEmail}
            className={`w-full py-3.5 rounded-2xl font-bold text-white shadow-lg transition-all flex items-center justify-center gap-2 ${
              mode === 'admin' ? 'bg-amber-600 hover:bg-amber-700' : 'bg-[#176e57] hover:bg-[#125744]'
            }`}
          >
            {isSendingEmail ? (
              <><RefreshCw className="w-4 h-4 animate-spin" /> Dispatching Code...</>
            ) : (
              'Sign In to JaniTracker'
            )}
          </button>
        </form>
      </div>

      {showOtpModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-xs w-full p-6 shadow-2xl space-y-4">
            <div className="text-center space-y-1">
              <div className="w-12 h-12 bg-emerald-100 text-[#176e57] rounded-full flex items-center justify-center mx-auto">
                <KeyRound className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 text-lg">Enter OTP Code</h3>
              <p className="text-xs text-slate-500">
                Code sent to <span className="font-medium text-slate-700">{getDestinationEmail(accountId)}</span>
              </p>
            </div>

            <form onSubmit={handleVerifyOtp} className="space-y-3">
              <input
                type="text"
                maxLength={6}
                required
                placeholder="123456"
                value={inputOtp}
                onChange={(e) => {
                  setInputOtp(e.target.value);
                  setOtpError('');
                }}
                className="w-full text-center tracking-widest font-mono text-xl py-3 bg-slate-50 border border-slate-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#176e57]"
              />

              {otpError && <p className="text-xs text-red-500 text-center font-medium">{otpError}</p>}

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowOtpModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 text-slate-600 rounded-xl font-medium text-xs hover:bg-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#176e57] text-white rounded-xl font-medium text-xs hover:bg-[#125744]"
                >
                  Verify
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}