import React, { useState, useRef } from 'react';
import { User, LogOut, X, Shield, Bell, ChevronRight } from 'lucide-react';

export default function Header({ user, setUser, broadcast }) {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  // Touch drag state for bottom sheet drawer
  const [dragY, setDragY] = useState(0);
  const touchStartY = useRef(0);

  const handleTouchStart = (e) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e) => {
    const currentY = e.touches[0].clientY;
    const deltaY = currentY - touchStartY.current;
    if (deltaY > 0) {
      setDragY(deltaY);
    }
  };

  const handleTouchEnd = () => {
    if (dragY > 75) {
      setIsProfileOpen(false);
    }
    setDragY(0);
  };

  const handleLogout = () => {
    localStorage.removeItem('sjc_active_user');
    sessionStorage.removeItem('sjc_active_user');
    setUser(null);
  };

  return (
    <>
      {/* Sticky Pine Green Top Bar */}
      <header className="sticky top-0 z-30 bg-[#176e57] text-white px-4 py-3 shadow-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-white text-[#176e57] rounded-xl flex items-center justify-center font-black text-lg shadow-sm">
            J
          </div>
          <div>
            <h1 className="text-sm font-bold leading-tight tracking-wide">JaniTracker</h1>
            <p className="text-[10px] text-emerald-100/80 font-medium">Dimasalang Hall</p>
          </div>
        </div>

        {/* Profile Avatar Button */}
        <button
          onClick={() => setIsProfileOpen(true)}
          className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-2.5 py-1.5 rounded-full transition-colors border border-white/10"
        >
          <div className="w-6 h-6 rounded-full bg-emerald-100 text-[#176e57] flex items-center justify-center text-xs font-bold">
            {user?.id ? user.id.slice(-2) : '00'}
          </div>
          <span className="text-xs font-medium max-w-[80px] truncate">
            {user?.role === 'admin' ? 'Admin' : `Staff #${user?.id}`}
          </span>
        </button>
      </header>

      {/* Interactive Bottom Sheet Profile Drawer */}
      {isProfileOpen && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-900/60 backdrop-blur-sm transition-opacity">
          {/* Backdrop Click */}
          <div className="flex-1" onClick={() => setIsProfileOpen(false)} />

          <div
            className="bg-white rounded-t-3xl p-5 shadow-2xl transition-transform duration-200 space-y-4 max-w-md mx-auto w-full"
            style={{ transform: `translateY(${dragY}px)` }}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            {/* Touch Pull Pill */}
            <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto cursor-grab active:cursor-grabbing" />

            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#176e57]/10 text-[#176e57] flex items-center justify-center font-bold text-lg">
                  {user?.role === 'admin' ? <Shield className="w-6 h-6 text-amber-600" /> : <User className="w-6 h-6" />}
                </div>
                <div>
                  <h3 className="font-bold text-slate-800 text-base">{user?.name}</h3>
                  <p className="text-xs text-slate-500 capitalize">Role: {user?.role}</p>
                </div>
              </div>
              <button
                onClick={() => setIsProfileOpen(false)}
                className="p-1.5 bg-slate-100 text-slate-500 rounded-full hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Account Info Details */}
            <div className="space-y-2 bg-slate-50 p-3.5 rounded-2xl border border-slate-200/60 text-xs text-slate-600">
              <div className="flex justify-between">
                <span className="text-slate-400">Account ID:</span>
                <span className="font-semibold text-slate-700">{user?.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Assigned Building:</span>
                <span className="font-semibold text-slate-700">Dimasalang Hall (7 Floors)</span>
              </div>
            </div>

            {/* Logout Action Button */}
            <button
              onClick={() => setShowLogoutModal(true)}
              className="w-full py-3 bg-red-50 text-red-600 hover:bg-red-100 font-semibold rounded-2xl text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <LogOut className="w-4 h-4" /> End Shift & Sign Out
            </button>
          </div>
        </div>
      )}

      {/* Logout Confirmation Modal */}
      {showLogoutModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xs w-full p-5 shadow-2xl text-center space-y-3">
            <div className="w-11 h-11 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mx-auto">
              <LogOut className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 text-base">Confirm Sign Out</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Are you sure you want to log out? Ensure all room statuses and incidents are updated in the Shift Handover Feed.
            </p>

            <div className="flex gap-2 pt-1">
              <button
                onClick={() => setShowLogoutModal(false)}
                className="flex-1 py-2.5 bg-slate-100 text-slate-600 rounded-xl font-semibold text-xs hover:bg-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleLogout}
                className="flex-1 py-2.5 bg-red-600 text-white rounded-xl font-semibold text-xs hover:bg-red-700 shadow-sm"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}